export default [{
	title: '创建时间',
	field: 'create_time',
	tooltip: '',
	formatter: ''
}, {
	title: '事件ID',
	field: 'event_key',
	stat: -1
}, {
	title: '事件参数',
	field: 'param',
	tooltip: '',
}, {
	title: '平台',
	field: 'platform',
	tooltip: '',
}, {
	title: '设备标识',
	field: 'device_id',
	tooltip: ''
}]
